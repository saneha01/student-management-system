import json
import os

FILE_NAME = "students.json"

# ------------------ Student Class ------------------
class Student:
    def __init__(self, student_id, name, grade):
        self.id = student_id
        self.name = name
        self.grade = grade

    def to_dict(self):
        return {"id": self.id, "name": self.name, "grade": self.grade}


# ------------------ Manager Class ------------------
class StudentManager:
    def __init__(self):
        self.students = []
        self.load_data()

    def load_data(self):
        if os.path.exists(FILE_NAME):
            with open(FILE_NAME, "r") as f:
                data = json.load(f)
                for s in data:
                    self.students.append(Student(s["id"], s["name"], s["grade"]))

    def save_data(self):
        with open(FILE_NAME, "w") as f:
            json.dump([s.to_dict() for s in self.students], f, indent=4)

    def id_exists(self, student_id):
        return any(s.id == student_id for s in self.students)

    def add_student(self):
        student_id = input("Enter ID: ")
        if self.id_exists(student_id):
            print(" ID already exists !")
            return

        name = input("Enter Name: ")
        grade = input("Enter Grade: ")
        self.students.append(Student(student_id, name, grade))
        self.save_data()
        print("Student Added")

    def update_student(self):
        student_id = input("Enter ID to update: ")
        for s in self.students:
            if s.id == student_id:
                s.name = input("New Name: ")
                s.grade = input("New Grade: ")
                self.save_data()
                print(" Student Updated!")
                return
        print(" Student not found!")

    def delete_student(self):
        student_id = input("Enter ID to delete: ")
        for s in self.students:
            if s.id == student_id:
                self.students.remove(s)
                self.save_data()
                print(" Student Deleted!")
                return
        print(" Student not found!")

    def list_students(self):
        if not self.students:
            print("No students found.")
            return

        print("\n{:<10}{:<20}{:<10}".format("ID", "Name", "Grade"))
        print("-" * 40)
        for s in self.students:
            print("{:<10}{:<20}{:<10}".format(s.id, s.name, s.grade))


# ------------------ Main Menu ------------------
def main():
    manager = StudentManager()

    while True:
        print("\n===== Student Management System =====")
        print("1. Add Student")
        print("2. Update Student")
        print("3. Delete Student")
        print("4. List Students")
        print("5. Exit")

        choice = input("Choose (1-5): ")

        if choice == "1":
            manager.add_student()
        elif choice == "2":
            manager.update_student()
        elif choice == "3":
            manager.delete_student()
        elif choice == "4":
            manager.list_students()
        elif choice == "5":
            print(" Goodbye!")
            break
        else:
            print(" Invalid choice!")

if __name__ == "__main__":
    main()
